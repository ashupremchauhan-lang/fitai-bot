const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = path.join(__dirname, '..', 'db', 'aifitbuddy.db');
const INIT_SQL = path.join(__dirname, '..', 'db', 'init.sql');

if (fs.existsSync(DB_PATH)) {
  console.log('Removing existing DB at', DB_PATH);
  fs.unlinkSync(DB_PATH);
}

const db = new Database(DB_PATH);
const initSql = fs.readFileSync(INIT_SQL, 'utf8');

try {
  db.exec(initSql);
  console.log('Database initialized at', DB_PATH);
} catch (err) {
  console.error('Failed to initialize DB:', err);
} finally {
  db.close();
}