require('dotenv').config();
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// API routes
const register = require('./src/api/register');
const generatePlan = require('./src/api/generatePlan');
const dbApi = require('./src/api/db');

app.post('/api/register', register);
app.post('/api/generate-plan', generatePlan);
app.get('/api/user/:email', dbApi.getUserByEmail);
app.get('/api/plans', dbApi.getPlans);

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`AiFitBuddy server running on http://localhost:${PORT}`);
});