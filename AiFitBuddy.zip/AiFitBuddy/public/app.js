// Frontend logic: register and generate plan

const form = document.getElementById('profileForm');
const generateBtn = document.getElementById('generateBtn');
const planEmailInput = document.getElementById('planEmail');
const planResult = document.getElementById('planResult');
const themeToggle = document.getElementById('themeToggle');

// theme
const saved = localStorage.getItem('aifit-theme');
if (saved === 'light') document.body.classList.remove('theme-dark'), document.body.classList.add('theme-light');

themeToggle.addEventListener('click', ()=>{
  document.body.classList.toggle('theme-light');
  const isLight = document.body.classList.contains('theme-light');
  localStorage.setItem('aifit-theme', isLight ? 'light' : 'dark');
});

form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  try{
    const res = await fetch('/api/register', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)});
    const j = await res.json();
    if (!res.ok) throw new Error(j.error || 'Register failed');
    alert('Registered successfully');
  }catch(err){
    alert('Error: ' + err.message);
  }
});

generateBtn.addEventListener('click', async ()=>{
  const email = planEmailInput.value.trim();
  if (!email) return alert('Enter email');
  try{
    const res = await fetch('/api/generate-plan', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email})});
    const j = await res.json();
    if (!res.ok) throw new Error(j.error || 'Failed');
    renderPlan(j);
  }catch(err){
    alert('Error: ' + err.message);
  }
});

function renderPlan(data){
  planResult.innerHTML = '';
  const u = data.user;
  const wrapper = document.createElement('div');
  wrapper.innerHTML = `
    <h3>Plan for ${u.name} (${u.email})</h3>
    <p>BMI: ${u.bmi} • BMR: ${data.bmr || 'N/A'} • TDEE: ${data.tdee || 'N/A'}</p>
    <h4>Selected plan: ${data.selected_plan.title}</h4>
    <p>${data.selected_plan.notes || ''}</p>
  `;
  // workout
  const w = data.selected_plan.workout || {};
  const meal = data.selected_plan.meal || {};

  const wdiv = document.createElement('div');
  wdiv.innerHTML = '<h5>Daily Workout</h5>';
  if (w.daily_workout) {
    const ul = document.createElement('ul');
    w.daily_workout.forEach(x=>{ const li = document.createElement('li'); li.textContent = `${x.name || JSON.stringify(x)} ${x.sets ? '- ' + x.sets + ' sets x ' + x.reps : x.duration ? '- ' + x.duration + ' min' : ''}`; ul.appendChild(li)});
    wdiv.appendChild(ul);
  }
  if (w.weekly_schedule) {
    const sched = document.createElement('div');
    sched.innerHTML = '<h5>Weekly Schedule</h5>';
    const pre = document.createElement('pre');
    pre.textContent = JSON.stringify(w.weekly_schedule, null, 2);
    sched.appendChild(pre);
    wdiv.appendChild(sched);
  }

  const mdiv = document.createElement('div');
  mdiv.innerHTML = '<h5>Sample Meal Plan</h5>';
  if (meal.breakfast || meal.lunch || meal.dinner || meal.snacks) {
    const ul = document.createElement('ul');
    ['breakfast','lunch','dinner','snacks'].forEach(k=>{ if (meal[k]){ const li = document.createElement('li'); li.innerHTML = `<strong>${k}:</strong> ${meal[k]}`; ul.appendChild(li)} });
    mdiv.appendChild(ul);
  } else {
    const pre = document.createElement('pre'); pre.textContent = JSON.stringify(meal, null, 2); mdiv.appendChild(pre);
  }

  planResult.appendChild(wrapper);
  planResult.appendChild(wdiv);
  planResult.appendChild(mdiv);
}