# AiFitBuddy

AI-Based Personalized Fitness & Lifestyle — Node.js + SQLite prototype

## Setup

1. Ensure Node.js (v16+) is installed.
2. Copy the project folder to your Desktop as `AiFitBuddy`.
3. In a terminal:

```bash
cd ~/Desktop/AiFitBuddy
npm install
node scripts/init-db.js
npm start
```

4. Open http://localhost:3000

## Scripts
- `npm run init-db` — initializes the SQLite DB with schema and seed data.

## API Endpoints
- POST `/api/register` — register a user
- POST `/api/generate-plan` — generate plan for a given email
- GET `/api/user/:email` — get user profile
- GET `/api/plans` — list available plan templates

## Notes
- Database: `db/aifitbuddy.db` created at runtime.
- The front-end is in `public/`.
