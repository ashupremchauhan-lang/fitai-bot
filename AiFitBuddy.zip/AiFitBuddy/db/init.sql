PRAGMA foreign_keys = ON;

CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  dob TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  age INTEGER,
  weight REAL,
  height REAL,
  gender TEXT,
  activity_level TEXT,
  weight_goal TEXT,
  fitness_goal TEXT,
  medical_history TEXT,
  allergies TEXT,
  diet_pref TEXT,
  bmi REAL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);

CREATE TABLE plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  diet_pref TEXT,
  fitness_goal TEXT,
  difficulty TEXT,
  workout_json TEXT,
  meal_json TEXT,
  notes TEXT
);

CREATE TABLE workouts (
  workout_id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  exercise_name TEXT,
  duration INTEGER,
  intensity TEXT,
  goal_type TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE diet_plans (
  diet_id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  meal_type TEXT,
  calories INTEGER,
  macronutrients TEXT,
  food_items TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE progress_logs (
  log_id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  date TEXT,
  weight REAL,
  bmi REAL,
  calories_burned INTEGER,
  activity_summary TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Seed at least 6 plan templates
INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Beginner Strength', 'Veg', 'Strength', 'Beginner', '{"daily_workout":[{"name":"Bodyweight Squat","sets":3,"reps":"10-12"},{"name":"Push-ups","sets":3,"reps":"8-12"}],"weekly_schedule":{"Mon":["Strength"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Strength"],"Fri":["Cardio"],"Sat":["Yoga"],"Sun":["Rest"]}}', '{"breakfast":"Poha with veggies","lunch":"Dal + Roti + Salad","dinner":"Sabzi + Roti","snacks":"Fruit and nuts"}', 'Beginner veg strength plan');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Beginner Strength', 'Non-Veg', 'Strength', 'Beginner', '{"daily_workout":[{"name":"Goblet Squat","sets":3,"reps":"8-10"},{"name":"Dumbbell Row","sets":3,"reps":"8-12"}],"weekly_schedule":{"Mon":["Strength"],"Tue":["Cardio"],"Wed":["Active Rest"],"Thu":["Strength"],"Fri":["Cardio"],"Sat":["Mobility"],"Sun":["Rest"]}}', '{"breakfast":"Egg omelette + oats","lunch":"Chicken curry + Rice","dinner":"Grilled fish + veggies","snacks":"Yogurt and fruit"}', 'Beginner non-veg strength plan');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Weight Loss', 'Veg', 'Weight Loss', 'Intermediate', '{"daily_workout":[{"name":"HIIT","duration":25}],"weekly_schedule":{"Mon":["HIIT"],"Tue":["Walk"],"Wed":["Strength"],"Thu":["HIIT"],"Fri":["Walk"],"Sat":["Yoga"],"Sun":["Rest"]}}', '{"breakfast":"Upma","lunch":"Salad + Dal","dinner":"Light soup + Roti","snacks":"Buttermilk"}', 'Veg weight loss plan');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Weight Loss', 'Non-Veg', 'Weight Loss', 'Intermediate', '{"daily_workout":[{"name":"Circuit Training","duration":30}],"weekly_schedule":{"Mon":["Circuit"],"Tue":["Walk"],"Wed":["Strength"],"Thu":["Circuit"],"Fri":["Walk"],"Sat":["Active Rest"],"Sun":["Rest"]}}', '{"breakfast":"Egg whites + salad","lunch":"Grilled chicken salad","dinner":"Steamed fish + veggies","snacks":"Mixed nuts"}', 'Non-veg weight loss plan');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg General Fitness', 'Any', 'General', 'Beginner', '{"daily_workout":[{"name":"Brisk Walk","duration":30},{"name":"Bodyweight circuit","sets":2}],"weekly_schedule":{"Mon":["Walk"],"Tue":["Circuit"],"Wed":["Yoga"],"Thu":["Walk"],"Fri":["Circuit"],"Sat":["Hike"],"Sun":["Rest"]}}', '{"breakfast":"Idli + sambar","lunch":"Veg thali","dinner":"Light veg meal","snacks":"Fruits"}', 'General fitness plan');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Beginner Flexibility', 'Any', 'Flexibility', 'Beginner', '{"daily_workout":[{"name":"Yoga","duration":30}],"weekly_schedule":{"Mon":["Yoga"],"Tue":["Mobility"],"Wed":["Yoga"],"Thu":["Mobility"],"Fri":["Yoga"],"Sat":["Light Walk"],"Sun":["Rest"]}}', '{"breakfast":"Smoothie","lunch":"Soup + salad","dinner":"Light meal","snacks":"Seeds"}', 'Flexibility and mobility plan');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Intermediate Strength', 'Veg', 'Strength', 'Intermediate', '{"daily_workout":[{"name":"Barbell Squat","sets":4,"reps":"6-8"},{"name":"Bench Press","sets":4,"reps":"6-8"},{"name":"Lat Pulldown","sets":3,"reps":"8-10"}],"weekly_schedule":{"Mon":["Upper Strength"],"Tue":["Cardio"],"Wed":["Lower Strength"],"Thu":["Mobility"],"Fri":["Full Body Strength"],"Sat":["Active Rest"],"Sun":["Rest"]}}', '{"breakfast":"Paneer bhurji + roti","lunch":"Rajma + rice + salad","dinner":"Mixed veg curry + roti","snacks":"Greek yogurt and nuts"}', 'Intermediate veg strength plan');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Intermediate Strength', 'Non-Veg', 'Strength', 'Intermediate', '{"daily_workout":[{"name":"Deadlift","sets":4,"reps":"5-6"},{"name":"Overhead Press","sets":4,"reps":"6-8"},{"name":"Pull-ups","sets":3,"reps":"Max"}],"weekly_schedule":{"Mon":["Lower Strength"],"Tue":["Cardio"],"Wed":["Upper Strength"],"Thu":["Mobility"],"Fri":["Full Body Strength"],"Sat":["Active Rest"],"Sun":["Rest"]}}', '{"breakfast":"Eggs with toast","lunch":"Chicken curry + rice + salad","dinner":"Grilled fish + sauteed veggies","snacks":"Boiled eggs and fruit"}', 'Intermediate non-veg strength focus plan');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Muscle Gain', 'Veg', 'Muscle Gain', 'Intermediate', '{"daily_workout":[{"name":"Barbell Squat","sets":4,"reps":"8-10"},{"name":"Incline Dumbbell Press","sets":4,"reps":"8-10"},{"name":"Seated Row","sets":3,"reps":"10-12"},{"name":"Romanian Deadlift","sets":3,"reps":"8-10"}],"weekly_schedule":{"Mon":["Push"],"Tue":["Pull"],"Wed":["Legs"],"Thu":["Rest"],"Fri":["Push"],"Sat":["Pull"],"Sun":["Rest"]}}', '{"breakfast":"Paneer stuffed paratha + curd","lunch":"Chole + rice + salad","dinner":"Soy chaap + roti","snacks":"Protein shake and peanuts"}', 'Veg mass gain plan with focus on compound lifts');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Muscle Gain', 'Non-Veg', 'Muscle Gain', 'Intermediate', '{"daily_workout":[{"name":"Back Squat","sets":4,"reps":"6-8"},{"name":"Flat Bench Press","sets":4,"reps":"6-8"},{"name":"Bent Over Row","sets":4,"reps":"8-10"},{"name":"Lunges","sets":3,"reps":"10 each leg"}],"weekly_schedule":{"Mon":["Chest Triceps"],"Tue":["Back Biceps"],"Wed":["Legs"],"Thu":["Rest"],"Fri":["Shoulders Arms"],"Sat":["Light Cardio"],"Sun":["Rest"]}}', '{"breakfast":"Egg bhurji + roti","lunch":"Chicken biryani with raita","dinner":"Fish curry + rice","snacks":"Protein shake and dry fruits"}', 'Non-veg muscle gain plan');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Advanced Strength', 'Veg', 'Strength', 'Advanced', '{"daily_workout":[{"name":"Back Squat","sets":5,"reps":"3-5"},{"name":"Bench Press","sets":5,"reps":"3-5"},{"name":"Weighted Pull-up","sets":4,"reps":"4-6"}],"weekly_schedule":{"Mon":["Heavy Squat"],"Tue":["Bench Volume"],"Wed":["Deadlift"],"Thu":["Accessory Work"],"Fri":["Heavy Bench"],"Sat":["Conditioning"],"Sun":["Rest"]}}', '{"breakfast":"Oats with milk, nuts and banana","lunch":"Dal makhani + rice + salad","dinner":"Paneer tikka + roti","snacks":"Protein smoothie"}', 'Advanced strength focus for experienced veg lifters');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Advanced Strength', 'Non-Veg', 'Strength', 'Advanced', '{"daily_workout":[{"name":"Low Bar Squat","sets":5,"reps":"3-5"},{"name":"Competition Bench","sets":5,"reps":"3-5"},{"name":"Conventional Deadlift","sets":5,"reps":"2-4"}],"weekly_schedule":{"Mon":["Squat Focus"],"Tue":["Bench Focus"],"Wed":["Deadlift Focus"],"Thu":["Hypertrophy"],"Fri":["Bench Volume"],"Sat":["GPP and Cardio"],"Sun":["Rest"]}}', '{"breakfast":"Egg and cheese sandwich","lunch":"Chicken curry + roti + salad","dinner":"Mutton curry + rice","snacks":"Protein shake and peanut butter toast"}', 'Advanced strength periodized plan for non-veg athletes');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Beginner Endurance', 'Any', 'Endurance', 'Beginner', '{"daily_workout":[{"name":"Easy Run","duration":25},{"name":"Walk","duration":20}],"weekly_schedule":{"Mon":["Easy Run"],"Tue":["Walk"],"Wed":["Rest"],"Thu":["Easy Run"],"Fri":["Walk"],"Sat":["Long Walk or Easy Run"],"Sun":["Rest"]}}', '{"breakfast":"Oats porridge","lunch":"Rice + dal + sabzi","dinner":"Light khichdi","snacks":"Banana and buttermilk"}', 'Beginner endurance plan with run walk structure');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Senior Mobility', 'Any', 'Mobility', 'Beginner', '{"daily_workout":[{"name":"Chair Squats","sets":2,"reps":"8-10"},{"name":"Wall Push-ups","sets":2,"reps":"8-10"},{"name":"Gentle Stretching","duration":15}],"weekly_schedule":{"Mon":["Low Impact Strength"],"Tue":["Walk"],"Wed":["Mobility"],"Thu":["Walk"],"Fri":["Low Impact Strength"],"Sat":["Gentle Yoga"],"Sun":["Rest"]}}', '{"breakfast":"Dalia with veggies","lunch":"Soft cooked dal + rice + curd","dinner":"Light vegetable stew","snacks":"Fruit and soaked almonds"}', 'Low impact plan for seniors focusing on mobility and joint health');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg PCOS Friendly Weight Loss', 'Veg', 'Weight Loss', 'Beginner', '{"daily_workout":[{"name":"Brisk Walk","duration":30},{"name":"Low Impact Strength Circuit","sets":2,"reps":"12-15"}],"weekly_schedule":{"Mon":["Walk"],"Tue":["Strength"],"Wed":["Yoga"],"Thu":["Walk"],"Fri":["Strength"],"Sat":["Yoga"],"Sun":["Rest"]}}', '{"breakfast":"Besan chilla with veggies","lunch":"Brown rice + dal + sabzi","dinner":"Sauteed veggies + paneer","snacks":"Roasted chana and buttermilk"}', 'Low impact plan suitable for hormonal balance and weight loss');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Office Fat Loss', 'Non-Veg', 'Weight Loss', 'Beginner', '{"daily_workout":[{"name":"Desk Mobility Routine","duration":10},{"name":"Evening Walk","duration":30}],"weekly_schedule":{"Mon":["Walk"],"Tue":["Walk"],"Wed":["Walk"],"Thu":["Walk"],"Fri":["Walk"],"Sat":["Light Strength"],"Sun":["Rest"]}}', '{"breakfast":"Boiled eggs + fruit","lunch":"Grilled chicken + salad","dinner":"Light fish curry + veggies","snacks":"Black coffee and nuts"}', 'For busy office workers with minimal time and equipment');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Home No Equipment', 'Veg', 'General', 'Beginner', '{"daily_workout":[{"name":"Jumping Jacks","sets":3,"reps":"20"},{"name":"Bodyweight Squats","sets":3,"reps":"12"},{"name":"Glute Bridge","sets":3,"reps":"12"},{"name":"Wall Sit","sets":3,"duration":30}],"weekly_schedule":{"Mon":["Full Body"],"Tue":["Walk"],"Wed":["Full Body"],"Thu":["Yoga"],"Fri":["Full Body"],"Sat":["Walk"],"Sun":["Rest"]}}', '{"breakfast":"Vegetable poha","lunch":"Roti + dal + sabzi + salad","dinner":"Vegetable khichdi","snacks":"Seasonal fruits"}', 'Home workout plan without equipment for general fitness');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Home Dumbbell Only', 'Non-Veg', 'General', 'Intermediate', '{"daily_workout":[{"name":"Dumbbell Squat","sets":3,"reps":"10-12"},{"name":"Dumbbell Bench Press","sets":3,"reps":"10-12"},{"name":"One Arm Row","sets":3,"reps":"10-12"},{"name":"Dumbbell Shoulder Press","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Upper Body"],"Tue":["Cardio"],"Wed":["Lower Body"],"Thu":["Cardio"],"Fri":["Full Body"],"Sat":["Active Rest"],"Sun":["Rest"]}}', '{"breakfast":"Omelette with veggies","lunch":"Chicken stir fry + rice","dinner":"Grilled fish + salad","snacks":"Yogurt and nuts"}', 'Home based plan using only dumbbells for all round fitness');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Desk Workers Anti Stiffness', 'Any', 'Mobility', 'Beginner', '{"daily_workout":[{"name":"Neck and Shoulder Mobility","duration":10},{"name":"Hip Opener Sequence","duration":10},{"name":"Posture Reset Routine","duration":10}],"weekly_schedule":{"Mon":["Mobility"],"Tue":["Walk"],"Wed":["Mobility"],"Thu":["Walk"],"Fri":["Mobility"],"Sat":["Light Walk"],"Sun":["Rest"]}}', '{"breakfast":"Smoothie with fruit and seeds","lunch":"Balanced thali with salad","dinner":"Light soup and roti","snacks":"Handful of nuts"}', 'For people who sit long hours to reduce stiffness and pain');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Cardio Focus Endurance', 'Veg', 'Endurance', 'Intermediate', '{"daily_workout":[{"name":"Steady State Run","duration":35},{"name":"Core Work","sets":3,"reps":"15"}],"weekly_schedule":{"Mon":["Easy Run"],"Tue":["Tempo Run"],"Wed":["Rest or Walk"],"Thu":["Intervals"],"Fri":["Easy Run"],"Sat":["Long Run"],"Sun":["Rest"]}}', '{"breakfast":"Oats with milk and banana","lunch":"Rice + dal + sabzi + curd","dinner":"Roti + light paneer curry","snacks":"Banana and dates"}', 'For building running endurance with vegetarian meals');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Cardio Plus Strength', 'Non-Veg', 'General', 'Intermediate', '{"daily_workout":[{"name":"Treadmill Run","duration":20},{"name":"Full Body Dumbbell Circuit","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Cardio"],"Tue":["Strength"],"Wed":["Cardio"],"Thu":["Strength"],"Fri":["Cardio"],"Sat":["Active Rest"],"Sun":["Rest"]}}', '{"breakfast":"Egg sandwich with veggies","lunch":"Grilled chicken + quinoa","dinner":"Fish tikka + salad","snacks":"Boiled eggs and fruit"}', 'Mix of strength and cardio for overall health and body composition');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Beginner Yoga and Mindfulness', 'Any', 'Flexibility', 'Beginner', '{"daily_workout":[{"name":"Sun Salutations","sets":5},{"name":"Basic Yoga Flow","duration":20},{"name":"Breathing and Relaxation","duration":10}],"weekly_schedule":{"Mon":["Yoga"],"Tue":["Walk"],"Wed":["Yoga"],"Thu":["Walk"],"Fri":["Yoga"],"Sat":["Meditation"],"Sun":["Rest"]}}', '{"breakfast":"Fruit bowl with nuts","lunch":"Vegetable stew + rice or roti","dinner":"Light khichdi or soup","snacks":"Herbal tea and seeds"}', 'For people wanting gentle flexibility and stress relief');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Lean Toning', 'Veg', 'Weight Loss', 'Intermediate', '{"daily_workout":[{"name":"Full Body Circuit","sets":3,"reps":"12-15"},{"name":"Low Intensity Cardio","duration":20}],"weekly_schedule":{"Mon":["Circuit"],"Tue":["Cardio"],"Wed":["Circuit"],"Thu":["Yoga"],"Fri":["Circuit"],"Sat":["Walk"],"Sun":["Rest"]}}', '{"breakfast":"Vegetable sandwich with whole wheat bread","lunch":"Salad + dal + millet roti","dinner":"Stir fried veggies + tofu","snacks":"Sprouts chaat"}', 'Focus on toning and fat loss for vegetarians');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Lean Recomp', 'Non-Veg', 'General', 'Intermediate', '{"daily_workout":[{"name":"Compound Strength Session","sets":4,"reps":"6-10"},{"name":"Moderate Cardio","duration":20}],"weekly_schedule":{"Mon":["Upper Strength"],"Tue":["Cardio"],"Wed":["Lower Strength"],"Thu":["Cardio"],"Fri":["Full Body Strength"],"Sat":["Active Rest"],"Sun":["Rest"]}}', '{"breakfast":"Eggs with oats","lunch":"Chicken curry + brown rice + salad","dinner":"Fish and vegetable stir fry","snacks":"Protein shake"}', 'Body recomposition plan to gain muscle and lose fat');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Strength Beginner Plan 1', 'Veg', 'Strength', 'Beginner', '{"daily_workout":[{"name":"Exercise 1A","sets":3,"reps":"10-12"},{"name":"Exercise 1B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 1 breakfast","lunch":"Plan 1 lunch","dinner":"Plan 1 dinner","snacks":"Plan 1 snacks"}', 'Seed plan 1 for Veg strength beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Strength Intermediate Plan 2', 'Veg', 'Strength', 'Intermediate', '{"daily_workout":[{"name":"Exercise 2A","sets":3,"reps":"10-12"},{"name":"Exercise 2B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 2 breakfast","lunch":"Plan 2 lunch","dinner":"Plan 2 dinner","snacks":"Plan 2 snacks"}', 'Seed plan 2 for Veg strength intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Strength Advanced Plan 3', 'Veg', 'Strength', 'Advanced', '{"daily_workout":[{"name":"Exercise 3A","sets":3,"reps":"10-12"},{"name":"Exercise 3B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 3 breakfast","lunch":"Plan 3 lunch","dinner":"Plan 3 dinner","snacks":"Plan 3 snacks"}', 'Seed plan 3 for Veg strength advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Weight Loss Beginner Plan 4', 'Veg', 'Weight Loss', 'Beginner', '{"daily_workout":[{"name":"Exercise 4A","sets":3,"reps":"10-12"},{"name":"Exercise 4B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 4 breakfast","lunch":"Plan 4 lunch","dinner":"Plan 4 dinner","snacks":"Plan 4 snacks"}', 'Seed plan 4 for Veg weight loss beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Weight Loss Intermediate Plan 5', 'Veg', 'Weight Loss', 'Intermediate', '{"daily_workout":[{"name":"Exercise 5A","sets":3,"reps":"10-12"},{"name":"Exercise 5B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 5 breakfast","lunch":"Plan 5 lunch","dinner":"Plan 5 dinner","snacks":"Plan 5 snacks"}', 'Seed plan 5 for Veg weight loss intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Weight Loss Advanced Plan 6', 'Veg', 'Weight Loss', 'Advanced', '{"daily_workout":[{"name":"Exercise 6A","sets":3,"reps":"10-12"},{"name":"Exercise 6B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 6 breakfast","lunch":"Plan 6 lunch","dinner":"Plan 6 dinner","snacks":"Plan 6 snacks"}', 'Seed plan 6 for Veg weight loss advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg General Beginner Plan 7', 'Veg', 'General', 'Beginner', '{"daily_workout":[{"name":"Exercise 7A","sets":3,"reps":"10-12"},{"name":"Exercise 7B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 7 breakfast","lunch":"Plan 7 lunch","dinner":"Plan 7 dinner","snacks":"Plan 7 snacks"}', 'Seed plan 7 for Veg general beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg General Intermediate Plan 8', 'Veg', 'General', 'Intermediate', '{"daily_workout":[{"name":"Exercise 8A","sets":3,"reps":"10-12"},{"name":"Exercise 8B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 8 breakfast","lunch":"Plan 8 lunch","dinner":"Plan 8 dinner","snacks":"Plan 8 snacks"}', 'Seed plan 8 for Veg general intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg General Advanced Plan 9', 'Veg', 'General', 'Advanced', '{"daily_workout":[{"name":"Exercise 9A","sets":3,"reps":"10-12"},{"name":"Exercise 9B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 9 breakfast","lunch":"Plan 9 lunch","dinner":"Plan 9 dinner","snacks":"Plan 9 snacks"}', 'Seed plan 9 for Veg general advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Flexibility Beginner Plan 10', 'Veg', 'Flexibility', 'Beginner', '{"daily_workout":[{"name":"Exercise 10A","sets":3,"reps":"10-12"},{"name":"Exercise 10B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 10 breakfast","lunch":"Plan 10 lunch","dinner":"Plan 10 dinner","snacks":"Plan 10 snacks"}', 'Seed plan 10 for Veg flexibility beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Flexibility Intermediate Plan 11', 'Veg', 'Flexibility', 'Intermediate', '{"daily_workout":[{"name":"Exercise 11A","sets":3,"reps":"10-12"},{"name":"Exercise 11B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 11 breakfast","lunch":"Plan 11 lunch","dinner":"Plan 11 dinner","snacks":"Plan 11 snacks"}', 'Seed plan 11 for Veg flexibility intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Flexibility Advanced Plan 12', 'Veg', 'Flexibility', 'Advanced', '{"daily_workout":[{"name":"Exercise 12A","sets":3,"reps":"10-12"},{"name":"Exercise 12B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 12 breakfast","lunch":"Plan 12 lunch","dinner":"Plan 12 dinner","snacks":"Plan 12 snacks"}', 'Seed plan 12 for Veg flexibility advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Endurance Beginner Plan 13', 'Veg', 'Endurance', 'Beginner', '{"daily_workout":[{"name":"Exercise 13A","sets":3,"reps":"10-12"},{"name":"Exercise 13B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 13 breakfast","lunch":"Plan 13 lunch","dinner":"Plan 13 dinner","snacks":"Plan 13 snacks"}', 'Seed plan 13 for Veg endurance beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Endurance Intermediate Plan 14', 'Veg', 'Endurance', 'Intermediate', '{"daily_workout":[{"name":"Exercise 14A","sets":3,"reps":"10-12"},{"name":"Exercise 14B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 14 breakfast","lunch":"Plan 14 lunch","dinner":"Plan 14 dinner","snacks":"Plan 14 snacks"}', 'Seed plan 14 for Veg endurance intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Endurance Advanced Plan 15', 'Veg', 'Endurance', 'Advanced', '{"daily_workout":[{"name":"Exercise 15A","sets":3,"reps":"10-12"},{"name":"Exercise 15B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 15 breakfast","lunch":"Plan 15 lunch","dinner":"Plan 15 dinner","snacks":"Plan 15 snacks"}', 'Seed plan 15 for Veg endurance advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Muscle Gain Beginner Plan 16', 'Veg', 'Muscle Gain', 'Beginner', '{"daily_workout":[{"name":"Exercise 16A","sets":3,"reps":"10-12"},{"name":"Exercise 16B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 16 breakfast","lunch":"Plan 16 lunch","dinner":"Plan 16 dinner","snacks":"Plan 16 snacks"}', 'Seed plan 16 for Veg muscle gain beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Muscle Gain Intermediate Plan 17', 'Veg', 'Muscle Gain', 'Intermediate', '{"daily_workout":[{"name":"Exercise 17A","sets":3,"reps":"10-12"},{"name":"Exercise 17B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 17 breakfast","lunch":"Plan 17 lunch","dinner":"Plan 17 dinner","snacks":"Plan 17 snacks"}', 'Seed plan 17 for Veg muscle gain intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Muscle Gain Advanced Plan 18', 'Veg', 'Muscle Gain', 'Advanced', '{"daily_workout":[{"name":"Exercise 18A","sets":3,"reps":"10-12"},{"name":"Exercise 18B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 18 breakfast","lunch":"Plan 18 lunch","dinner":"Plan 18 dinner","snacks":"Plan 18 snacks"}', 'Seed plan 18 for Veg muscle gain advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Mobility Beginner Plan 19', 'Veg', 'Mobility', 'Beginner', '{"daily_workout":[{"name":"Exercise 19A","sets":3,"reps":"10-12"},{"name":"Exercise 19B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 19 breakfast","lunch":"Plan 19 lunch","dinner":"Plan 19 dinner","snacks":"Plan 19 snacks"}', 'Seed plan 19 for Veg mobility beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Mobility Intermediate Plan 20', 'Veg', 'Mobility', 'Intermediate', '{"daily_workout":[{"name":"Exercise 20A","sets":3,"reps":"10-12"},{"name":"Exercise 20B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 20 breakfast","lunch":"Plan 20 lunch","dinner":"Plan 20 dinner","snacks":"Plan 20 snacks"}', 'Seed plan 20 for Veg mobility intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Mobility Advanced Plan 21', 'Veg', 'Mobility', 'Advanced', '{"daily_workout":[{"name":"Exercise 21A","sets":3,"reps":"10-12"},{"name":"Exercise 21B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 21 breakfast","lunch":"Plan 21 lunch","dinner":"Plan 21 dinner","snacks":"Plan 21 snacks"}', 'Seed plan 21 for Veg mobility advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Rehab Beginner Plan 22', 'Veg', 'Rehab', 'Beginner', '{"daily_workout":[{"name":"Exercise 22A","sets":3,"reps":"10-12"},{"name":"Exercise 22B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 22 breakfast","lunch":"Plan 22 lunch","dinner":"Plan 22 dinner","snacks":"Plan 22 snacks"}', 'Seed plan 22 for Veg rehab beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Rehab Intermediate Plan 23', 'Veg', 'Rehab', 'Intermediate', '{"daily_workout":[{"name":"Exercise 23A","sets":3,"reps":"10-12"},{"name":"Exercise 23B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 23 breakfast","lunch":"Plan 23 lunch","dinner":"Plan 23 dinner","snacks":"Plan 23 snacks"}', 'Seed plan 23 for Veg rehab intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Rehab Advanced Plan 24', 'Veg', 'Rehab', 'Advanced', '{"daily_workout":[{"name":"Exercise 24A","sets":3,"reps":"10-12"},{"name":"Exercise 24B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 24 breakfast","lunch":"Plan 24 lunch","dinner":"Plan 24 dinner","snacks":"Plan 24 snacks"}', 'Seed plan 24 for Veg rehab advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Sports Beginner Plan 25', 'Veg', 'Sports', 'Beginner', '{"daily_workout":[{"name":"Exercise 25A","sets":3,"reps":"10-12"},{"name":"Exercise 25B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 25 breakfast","lunch":"Plan 25 lunch","dinner":"Plan 25 dinner","snacks":"Plan 25 snacks"}', 'Seed plan 25 for Veg sports beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Sports Intermediate Plan 26', 'Veg', 'Sports', 'Intermediate', '{"daily_workout":[{"name":"Exercise 26A","sets":3,"reps":"10-12"},{"name":"Exercise 26B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 26 breakfast","lunch":"Plan 26 lunch","dinner":"Plan 26 dinner","snacks":"Plan 26 snacks"}', 'Seed plan 26 for Veg sports intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Veg Sports Advanced Plan 27', 'Veg', 'Sports', 'Advanced', '{"daily_workout":[{"name":"Exercise 27A","sets":3,"reps":"10-12"},{"name":"Exercise 27B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 27 breakfast","lunch":"Plan 27 lunch","dinner":"Plan 27 dinner","snacks":"Plan 27 snacks"}', 'Seed plan 27 for Veg sports advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Strength Beginner Plan 28', 'Non-Veg', 'Strength', 'Beginner', '{"daily_workout":[{"name":"Exercise 28A","sets":3,"reps":"10-12"},{"name":"Exercise 28B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 28 breakfast","lunch":"Plan 28 lunch","dinner":"Plan 28 dinner","snacks":"Plan 28 snacks"}', 'Seed plan 28 for Non-Veg strength beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Strength Intermediate Plan 29', 'Non-Veg', 'Strength', 'Intermediate', '{"daily_workout":[{"name":"Exercise 29A","sets":3,"reps":"10-12"},{"name":"Exercise 29B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 29 breakfast","lunch":"Plan 29 lunch","dinner":"Plan 29 dinner","snacks":"Plan 29 snacks"}', 'Seed plan 29 for Non-Veg strength intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Strength Advanced Plan 30', 'Non-Veg', 'Strength', 'Advanced', '{"daily_workout":[{"name":"Exercise 30A","sets":3,"reps":"10-12"},{"name":"Exercise 30B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 30 breakfast","lunch":"Plan 30 lunch","dinner":"Plan 30 dinner","snacks":"Plan 30 snacks"}', 'Seed plan 30 for Non-Veg strength advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Weight Loss Beginner Plan 31', 'Non-Veg', 'Weight Loss', 'Beginner', '{"daily_workout":[{"name":"Exercise 31A","sets":3,"reps":"10-12"},{"name":"Exercise 31B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 31 breakfast","lunch":"Plan 31 lunch","dinner":"Plan 31 dinner","snacks":"Plan 31 snacks"}', 'Seed plan 31 for Non-Veg weight loss beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Weight Loss Intermediate Plan 32', 'Non-Veg', 'Weight Loss', 'Intermediate', '{"daily_workout":[{"name":"Exercise 32A","sets":3,"reps":"10-12"},{"name":"Exercise 32B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 32 breakfast","lunch":"Plan 32 lunch","dinner":"Plan 32 dinner","snacks":"Plan 32 snacks"}', 'Seed plan 32 for Non-Veg weight loss intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Weight Loss Advanced Plan 33', 'Non-Veg', 'Weight Loss', 'Advanced', '{"daily_workout":[{"name":"Exercise 33A","sets":3,"reps":"10-12"},{"name":"Exercise 33B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 33 breakfast","lunch":"Plan 33 lunch","dinner":"Plan 33 dinner","snacks":"Plan 33 snacks"}', 'Seed plan 33 for Non-Veg weight loss advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg General Beginner Plan 34', 'Non-Veg', 'General', 'Beginner', '{"daily_workout":[{"name":"Exercise 34A","sets":3,"reps":"10-12"},{"name":"Exercise 34B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 34 breakfast","lunch":"Plan 34 lunch","dinner":"Plan 34 dinner","snacks":"Plan 34 snacks"}', 'Seed plan 34 for Non-Veg general beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg General Intermediate Plan 35', 'Non-Veg', 'General', 'Intermediate', '{"daily_workout":[{"name":"Exercise 35A","sets":3,"reps":"10-12"},{"name":"Exercise 35B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 35 breakfast","lunch":"Plan 35 lunch","dinner":"Plan 35 dinner","snacks":"Plan 35 snacks"}', 'Seed plan 35 for Non-Veg general intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg General Advanced Plan 36', 'Non-Veg', 'General', 'Advanced', '{"daily_workout":[{"name":"Exercise 36A","sets":3,"reps":"10-12"},{"name":"Exercise 36B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 36 breakfast","lunch":"Plan 36 lunch","dinner":"Plan 36 dinner","snacks":"Plan 36 snacks"}', 'Seed plan 36 for Non-Veg general advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Flexibility Beginner Plan 37', 'Non-Veg', 'Flexibility', 'Beginner', '{"daily_workout":[{"name":"Exercise 37A","sets":3,"reps":"10-12"},{"name":"Exercise 37B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 37 breakfast","lunch":"Plan 37 lunch","dinner":"Plan 37 dinner","snacks":"Plan 37 snacks"}', 'Seed plan 37 for Non-Veg flexibility beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Flexibility Intermediate Plan 38', 'Non-Veg', 'Flexibility', 'Intermediate', '{"daily_workout":[{"name":"Exercise 38A","sets":3,"reps":"10-12"},{"name":"Exercise 38B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 38 breakfast","lunch":"Plan 38 lunch","dinner":"Plan 38 dinner","snacks":"Plan 38 snacks"}', 'Seed plan 38 for Non-Veg flexibility intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Flexibility Advanced Plan 39', 'Non-Veg', 'Flexibility', 'Advanced', '{"daily_workout":[{"name":"Exercise 39A","sets":3,"reps":"10-12"},{"name":"Exercise 39B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 39 breakfast","lunch":"Plan 39 lunch","dinner":"Plan 39 dinner","snacks":"Plan 39 snacks"}', 'Seed plan 39 for Non-Veg flexibility advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Endurance Beginner Plan 40', 'Non-Veg', 'Endurance', 'Beginner', '{"daily_workout":[{"name":"Exercise 40A","sets":3,"reps":"10-12"},{"name":"Exercise 40B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 40 breakfast","lunch":"Plan 40 lunch","dinner":"Plan 40 dinner","snacks":"Plan 40 snacks"}', 'Seed plan 40 for Non-Veg endurance beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Endurance Intermediate Plan 41', 'Non-Veg', 'Endurance', 'Intermediate', '{"daily_workout":[{"name":"Exercise 41A","sets":3,"reps":"10-12"},{"name":"Exercise 41B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 41 breakfast","lunch":"Plan 41 lunch","dinner":"Plan 41 dinner","snacks":"Plan 41 snacks"}', 'Seed plan 41 for Non-Veg endurance intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Endurance Advanced Plan 42', 'Non-Veg', 'Endurance', 'Advanced', '{"daily_workout":[{"name":"Exercise 42A","sets":3,"reps":"10-12"},{"name":"Exercise 42B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 42 breakfast","lunch":"Plan 42 lunch","dinner":"Plan 42 dinner","snacks":"Plan 42 snacks"}', 'Seed plan 42 for Non-Veg endurance advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Muscle Gain Beginner Plan 43', 'Non-Veg', 'Muscle Gain', 'Beginner', '{"daily_workout":[{"name":"Exercise 43A","sets":3,"reps":"10-12"},{"name":"Exercise 43B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 43 breakfast","lunch":"Plan 43 lunch","dinner":"Plan 43 dinner","snacks":"Plan 43 snacks"}', 'Seed plan 43 for Non-Veg muscle gain beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Muscle Gain Intermediate Plan 44', 'Non-Veg', 'Muscle Gain', 'Intermediate', '{"daily_workout":[{"name":"Exercise 44A","sets":3,"reps":"10-12"},{"name":"Exercise 44B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 44 breakfast","lunch":"Plan 44 lunch","dinner":"Plan 44 dinner","snacks":"Plan 44 snacks"}', 'Seed plan 44 for Non-Veg muscle gain intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Muscle Gain Advanced Plan 45', 'Non-Veg', 'Muscle Gain', 'Advanced', '{"daily_workout":[{"name":"Exercise 45A","sets":3,"reps":"10-12"},{"name":"Exercise 45B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 45 breakfast","lunch":"Plan 45 lunch","dinner":"Plan 45 dinner","snacks":"Plan 45 snacks"}', 'Seed plan 45 for Non-Veg muscle gain advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Mobility Beginner Plan 46', 'Non-Veg', 'Mobility', 'Beginner', '{"daily_workout":[{"name":"Exercise 46A","sets":3,"reps":"10-12"},{"name":"Exercise 46B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 46 breakfast","lunch":"Plan 46 lunch","dinner":"Plan 46 dinner","snacks":"Plan 46 snacks"}', 'Seed plan 46 for Non-Veg mobility beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Mobility Intermediate Plan 47', 'Non-Veg', 'Mobility', 'Intermediate', '{"daily_workout":[{"name":"Exercise 47A","sets":3,"reps":"10-12"},{"name":"Exercise 47B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 47 breakfast","lunch":"Plan 47 lunch","dinner":"Plan 47 dinner","snacks":"Plan 47 snacks"}', 'Seed plan 47 for Non-Veg mobility intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Mobility Advanced Plan 48', 'Non-Veg', 'Mobility', 'Advanced', '{"daily_workout":[{"name":"Exercise 48A","sets":3,"reps":"10-12"},{"name":"Exercise 48B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 48 breakfast","lunch":"Plan 48 lunch","dinner":"Plan 48 dinner","snacks":"Plan 48 snacks"}', 'Seed plan 48 for Non-Veg mobility advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Rehab Beginner Plan 49', 'Non-Veg', 'Rehab', 'Beginner', '{"daily_workout":[{"name":"Exercise 49A","sets":3,"reps":"10-12"},{"name":"Exercise 49B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 49 breakfast","lunch":"Plan 49 lunch","dinner":"Plan 49 dinner","snacks":"Plan 49 snacks"}', 'Seed plan 49 for Non-Veg rehab beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Rehab Intermediate Plan 50', 'Non-Veg', 'Rehab', 'Intermediate', '{"daily_workout":[{"name":"Exercise 50A","sets":3,"reps":"10-12"},{"name":"Exercise 50B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 50 breakfast","lunch":"Plan 50 lunch","dinner":"Plan 50 dinner","snacks":"Plan 50 snacks"}', 'Seed plan 50 for Non-Veg rehab intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Rehab Advanced Plan 51', 'Non-Veg', 'Rehab', 'Advanced', '{"daily_workout":[{"name":"Exercise 51A","sets":3,"reps":"10-12"},{"name":"Exercise 51B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 51 breakfast","lunch":"Plan 51 lunch","dinner":"Plan 51 dinner","snacks":"Plan 51 snacks"}', 'Seed plan 51 for Non-Veg rehab advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Sports Beginner Plan 52', 'Non-Veg', 'Sports', 'Beginner', '{"daily_workout":[{"name":"Exercise 52A","sets":3,"reps":"10-12"},{"name":"Exercise 52B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 52 breakfast","lunch":"Plan 52 lunch","dinner":"Plan 52 dinner","snacks":"Plan 52 snacks"}', 'Seed plan 52 for Non-Veg sports beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Sports Intermediate Plan 53', 'Non-Veg', 'Sports', 'Intermediate', '{"daily_workout":[{"name":"Exercise 53A","sets":3,"reps":"10-12"},{"name":"Exercise 53B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 53 breakfast","lunch":"Plan 53 lunch","dinner":"Plan 53 dinner","snacks":"Plan 53 snacks"}', 'Seed plan 53 for Non-Veg sports intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Non-Veg Sports Advanced Plan 54', 'Non-Veg', 'Sports', 'Advanced', '{"daily_workout":[{"name":"Exercise 54A","sets":3,"reps":"10-12"},{"name":"Exercise 54B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 54 breakfast","lunch":"Plan 54 lunch","dinner":"Plan 54 dinner","snacks":"Plan 54 snacks"}', 'Seed plan 54 for Non-Veg sports advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Strength Beginner Plan 55', 'Any', 'Strength', 'Beginner', '{"daily_workout":[{"name":"Exercise 55A","sets":3,"reps":"10-12"},{"name":"Exercise 55B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 55 breakfast","lunch":"Plan 55 lunch","dinner":"Plan 55 dinner","snacks":"Plan 55 snacks"}', 'Seed plan 55 for Any strength beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Strength Intermediate Plan 56', 'Any', 'Strength', 'Intermediate', '{"daily_workout":[{"name":"Exercise 56A","sets":3,"reps":"10-12"},{"name":"Exercise 56B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 56 breakfast","lunch":"Plan 56 lunch","dinner":"Plan 56 dinner","snacks":"Plan 56 snacks"}', 'Seed plan 56 for Any strength intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Strength Advanced Plan 57', 'Any', 'Strength', 'Advanced', '{"daily_workout":[{"name":"Exercise 57A","sets":3,"reps":"10-12"},{"name":"Exercise 57B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 57 breakfast","lunch":"Plan 57 lunch","dinner":"Plan 57 dinner","snacks":"Plan 57 snacks"}', 'Seed plan 57 for Any strength advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Weight Loss Beginner Plan 58', 'Any', 'Weight Loss', 'Beginner', '{"daily_workout":[{"name":"Exercise 58A","sets":3,"reps":"10-12"},{"name":"Exercise 58B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 58 breakfast","lunch":"Plan 58 lunch","dinner":"Plan 58 dinner","snacks":"Plan 58 snacks"}', 'Seed plan 58 for Any weight loss beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Weight Loss Intermediate Plan 59', 'Any', 'Weight Loss', 'Intermediate', '{"daily_workout":[{"name":"Exercise 59A","sets":3,"reps":"10-12"},{"name":"Exercise 59B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 59 breakfast","lunch":"Plan 59 lunch","dinner":"Plan 59 dinner","snacks":"Plan 59 snacks"}', 'Seed plan 59 for Any weight loss intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Weight Loss Advanced Plan 60', 'Any', 'Weight Loss', 'Advanced', '{"daily_workout":[{"name":"Exercise 60A","sets":3,"reps":"10-12"},{"name":"Exercise 60B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 60 breakfast","lunch":"Plan 60 lunch","dinner":"Plan 60 dinner","snacks":"Plan 60 snacks"}', 'Seed plan 60 for Any weight loss advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any General Beginner Plan 61', 'Any', 'General', 'Beginner', '{"daily_workout":[{"name":"Exercise 61A","sets":3,"reps":"10-12"},{"name":"Exercise 61B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 61 breakfast","lunch":"Plan 61 lunch","dinner":"Plan 61 dinner","snacks":"Plan 61 snacks"}', 'Seed plan 61 for Any general beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any General Intermediate Plan 62', 'Any', 'General', 'Intermediate', '{"daily_workout":[{"name":"Exercise 62A","sets":3,"reps":"10-12"},{"name":"Exercise 62B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 62 breakfast","lunch":"Plan 62 lunch","dinner":"Plan 62 dinner","snacks":"Plan 62 snacks"}', 'Seed plan 62 for Any general intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any General Advanced Plan 63', 'Any', 'General', 'Advanced', '{"daily_workout":[{"name":"Exercise 63A","sets":3,"reps":"10-12"},{"name":"Exercise 63B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 63 breakfast","lunch":"Plan 63 lunch","dinner":"Plan 63 dinner","snacks":"Plan 63 snacks"}', 'Seed plan 63 for Any general advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Flexibility Beginner Plan 64', 'Any', 'Flexibility', 'Beginner', '{"daily_workout":[{"name":"Exercise 64A","sets":3,"reps":"10-12"},{"name":"Exercise 64B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 64 breakfast","lunch":"Plan 64 lunch","dinner":"Plan 64 dinner","snacks":"Plan 64 snacks"}', 'Seed plan 64 for Any flexibility beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Flexibility Intermediate Plan 65', 'Any', 'Flexibility', 'Intermediate', '{"daily_workout":[{"name":"Exercise 65A","sets":3,"reps":"10-12"},{"name":"Exercise 65B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 65 breakfast","lunch":"Plan 65 lunch","dinner":"Plan 65 dinner","snacks":"Plan 65 snacks"}', 'Seed plan 65 for Any flexibility intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Flexibility Advanced Plan 66', 'Any', 'Flexibility', 'Advanced', '{"daily_workout":[{"name":"Exercise 66A","sets":3,"reps":"10-12"},{"name":"Exercise 66B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 66 breakfast","lunch":"Plan 66 lunch","dinner":"Plan 66 dinner","snacks":"Plan 66 snacks"}', 'Seed plan 66 for Any flexibility advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Endurance Beginner Plan 67', 'Any', 'Endurance', 'Beginner', '{"daily_workout":[{"name":"Exercise 67A","sets":3,"reps":"10-12"},{"name":"Exercise 67B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 67 breakfast","lunch":"Plan 67 lunch","dinner":"Plan 67 dinner","snacks":"Plan 67 snacks"}', 'Seed plan 67 for Any endurance beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Endurance Intermediate Plan 68', 'Any', 'Endurance', 'Intermediate', '{"daily_workout":[{"name":"Exercise 68A","sets":3,"reps":"10-12"},{"name":"Exercise 68B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 68 breakfast","lunch":"Plan 68 lunch","dinner":"Plan 68 dinner","snacks":"Plan 68 snacks"}', 'Seed plan 68 for Any endurance intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Endurance Advanced Plan 69', 'Any', 'Endurance', 'Advanced', '{"daily_workout":[{"name":"Exercise 69A","sets":3,"reps":"10-12"},{"name":"Exercise 69B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 69 breakfast","lunch":"Plan 69 lunch","dinner":"Plan 69 dinner","snacks":"Plan 69 snacks"}', 'Seed plan 69 for Any endurance advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Muscle Gain Beginner Plan 70', 'Any', 'Muscle Gain', 'Beginner', '{"daily_workout":[{"name":"Exercise 70A","sets":3,"reps":"10-12"},{"name":"Exercise 70B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 70 breakfast","lunch":"Plan 70 lunch","dinner":"Plan 70 dinner","snacks":"Plan 70 snacks"}', 'Seed plan 70 for Any muscle gain beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Muscle Gain Intermediate Plan 71', 'Any', 'Muscle Gain', 'Intermediate', '{"daily_workout":[{"name":"Exercise 71A","sets":3,"reps":"10-12"},{"name":"Exercise 71B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 71 breakfast","lunch":"Plan 71 lunch","dinner":"Plan 71 dinner","snacks":"Plan 71 snacks"}', 'Seed plan 71 for Any muscle gain intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Muscle Gain Advanced Plan 72', 'Any', 'Muscle Gain', 'Advanced', '{"daily_workout":[{"name":"Exercise 72A","sets":3,"reps":"10-12"},{"name":"Exercise 72B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 72 breakfast","lunch":"Plan 72 lunch","dinner":"Plan 72 dinner","snacks":"Plan 72 snacks"}', 'Seed plan 72 for Any muscle gain advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Mobility Beginner Plan 73', 'Any', 'Mobility', 'Beginner', '{"daily_workout":[{"name":"Exercise 73A","sets":3,"reps":"10-12"},{"name":"Exercise 73B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 73 breakfast","lunch":"Plan 73 lunch","dinner":"Plan 73 dinner","snacks":"Plan 73 snacks"}', 'Seed plan 73 for Any mobility beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Mobility Intermediate Plan 74', 'Any', 'Mobility', 'Intermediate', '{"daily_workout":[{"name":"Exercise 74A","sets":3,"reps":"10-12"},{"name":"Exercise 74B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 74 breakfast","lunch":"Plan 74 lunch","dinner":"Plan 74 dinner","snacks":"Plan 74 snacks"}', 'Seed plan 74 for Any mobility intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Mobility Advanced Plan 75', 'Any', 'Mobility', 'Advanced', '{"daily_workout":[{"name":"Exercise 75A","sets":3,"reps":"10-12"},{"name":"Exercise 75B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 75 breakfast","lunch":"Plan 75 lunch","dinner":"Plan 75 dinner","snacks":"Plan 75 snacks"}', 'Seed plan 75 for Any mobility advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Rehab Beginner Plan 76', 'Any', 'Rehab', 'Beginner', '{"daily_workout":[{"name":"Exercise 76A","sets":3,"reps":"10-12"},{"name":"Exercise 76B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 76 breakfast","lunch":"Plan 76 lunch","dinner":"Plan 76 dinner","snacks":"Plan 76 snacks"}', 'Seed plan 76 for Any rehab beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Rehab Intermediate Plan 77', 'Any', 'Rehab', 'Intermediate', '{"daily_workout":[{"name":"Exercise 77A","sets":3,"reps":"10-12"},{"name":"Exercise 77B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 77 breakfast","lunch":"Plan 77 lunch","dinner":"Plan 77 dinner","snacks":"Plan 77 snacks"}', 'Seed plan 77 for Any rehab intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Rehab Advanced Plan 78', 'Any', 'Rehab', 'Advanced', '{"daily_workout":[{"name":"Exercise 78A","sets":3,"reps":"10-12"},{"name":"Exercise 78B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 78 breakfast","lunch":"Plan 78 lunch","dinner":"Plan 78 dinner","snacks":"Plan 78 snacks"}', 'Seed plan 78 for Any rehab advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Sports Beginner Plan 79', 'Any', 'Sports', 'Beginner', '{"daily_workout":[{"name":"Exercise 79A","sets":3,"reps":"10-12"},{"name":"Exercise 79B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 79 breakfast","lunch":"Plan 79 lunch","dinner":"Plan 79 dinner","snacks":"Plan 79 snacks"}', 'Seed plan 79 for Any sports beginner');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Sports Intermediate Plan 80', 'Any', 'Sports', 'Intermediate', '{"daily_workout":[{"name":"Exercise 80A","sets":3,"reps":"10-12"},{"name":"Exercise 80B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 80 breakfast","lunch":"Plan 80 lunch","dinner":"Plan 80 dinner","snacks":"Plan 80 snacks"}', 'Seed plan 80 for Any sports intermediate');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Sports Advanced Plan 81', 'Any', 'Sports', 'Advanced', '{"daily_workout":[{"name":"Exercise 81A","sets":3,"reps":"10-12"},{"name":"Exercise 81B","sets":3,"reps":"10-12"}],"weekly_schedule":{"Mon":["Session"],"Tue":["Cardio"],"Wed":["Rest"],"Thu":["Session"],"Fri":["Cardio"],"Sat":["Active"],"Sun":["Rest"]}}', '{"breakfast":"Plan 81 breakfast","lunch":"Plan 81 lunch","dinner":"Plan 81 dinner","snacks":"Plan 81 snacks"}', 'Seed plan 81 for Any sports advanced');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Postpartum Beginner Plan 82', 'Any', 'Postpartum', 'Beginner', '{"daily_workout":[{"name":"Special 82A","duration":25},{"name":"Special 82B","duration":15}],"weekly_schedule":{"Mon":["Routine"],"Tue":["Walk"],"Wed":["Routine"],"Thu":["Walk"],"Fri":["Routine"],"Sat":["Light"],"Sun":["Rest"]}}', '{"breakfast":"Extra 82 breakfast","lunch":"Extra 82 lunch","dinner":"Extra 82 dinner","snacks":"Extra 82 snacks"}', 'Additional seed plan 82 for postpartum');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Postpartum Intermediate Plan 83', 'Any', 'Postpartum', 'Intermediate', '{"daily_workout":[{"name":"Special 83A","duration":25},{"name":"Special 83B","duration":15}],"weekly_schedule":{"Mon":["Routine"],"Tue":["Walk"],"Wed":["Routine"],"Thu":["Walk"],"Fri":["Routine"],"Sat":["Light"],"Sun":["Rest"]}}', '{"breakfast":"Extra 83 breakfast","lunch":"Extra 83 lunch","dinner":"Extra 83 dinner","snacks":"Extra 83 snacks"}', 'Additional seed plan 83 for postpartum');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Postpartum Advanced Plan 84', 'Any', 'Postpartum', 'Advanced', '{"daily_workout":[{"name":"Special 84A","duration":25},{"name":"Special 84B","duration":15}],"weekly_schedule":{"Mon":["Routine"],"Tue":["Walk"],"Wed":["Routine"],"Thu":["Walk"],"Fri":["Routine"],"Sat":["Light"],"Sun":["Rest"]}}', '{"breakfast":"Extra 84 breakfast","lunch":"Extra 84 lunch","dinner":"Extra 84 dinner","snacks":"Extra 84 snacks"}', 'Additional seed plan 84 for postpartum');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Teen Fitness Beginner Plan 85', 'Any', 'Teen Fitness', 'Beginner', '{"daily_workout":[{"name":"Special 85A","duration":25},{"name":"Special 85B","duration":15}],"weekly_schedule":{"Mon":["Routine"],"Tue":["Walk"],"Wed":["Routine"],"Thu":["Walk"],"Fri":["Routine"],"Sat":["Light"],"Sun":["Rest"]}}', '{"breakfast":"Extra 85 breakfast","lunch":"Extra 85 lunch","dinner":"Extra 85 dinner","snacks":"Extra 85 snacks"}', 'Additional seed plan 85 for teen fitness');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Teen Fitness Intermediate Plan 86', 'Any', 'Teen Fitness', 'Intermediate', '{"daily_workout":[{"name":"Special 86A","duration":25},{"name":"Special 86B","duration":15}],"weekly_schedule":{"Mon":["Routine"],"Tue":["Walk"],"Wed":["Routine"],"Thu":["Walk"],"Fri":["Routine"],"Sat":["Light"],"Sun":["Rest"]}}', '{"breakfast":"Extra 86 breakfast","lunch":"Extra 86 lunch","dinner":"Extra 86 dinner","snacks":"Extra 86 snacks"}', 'Additional seed plan 86 for teen fitness');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Teen Fitness Advanced Plan 87', 'Any', 'Teen Fitness', 'Advanced', '{"daily_workout":[{"name":"Special 87A","duration":25},{"name":"Special 87B","duration":15}],"weekly_schedule":{"Mon":["Routine"],"Tue":["Walk"],"Wed":["Routine"],"Thu":["Walk"],"Fri":["Routine"],"Sat":["Light"],"Sun":["Rest"]}}', '{"breakfast":"Extra 87 breakfast","lunch":"Extra 87 lunch","dinner":"Extra 87 dinner","snacks":"Extra 87 snacks"}', 'Additional seed plan 87 for teen fitness');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Senior Care Beginner Plan 88', 'Any', 'Senior Care', 'Beginner', '{"daily_workout":[{"name":"Special 88A","duration":25},{"name":"Special 88B","duration":15}],"weekly_schedule":{"Mon":["Routine"],"Tue":["Walk"],"Wed":["Routine"],"Thu":["Walk"],"Fri":["Routine"],"Sat":["Light"],"Sun":["Rest"]}}', '{"breakfast":"Extra 88 breakfast","lunch":"Extra 88 lunch","dinner":"Extra 88 dinner","snacks":"Extra 88 snacks"}', 'Additional seed plan 88 for senior care');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Senior Care Intermediate Plan 89', 'Any', 'Senior Care', 'Intermediate', '{"daily_workout":[{"name":"Special 89A","duration":25},{"name":"Special 89B","duration":15}],"weekly_schedule":{"Mon":["Routine"],"Tue":["Walk"],"Wed":["Routine"],"Thu":["Walk"],"Fri":["Routine"],"Sat":["Light"],"Sun":["Rest"]}}', '{"breakfast":"Extra 89 breakfast","lunch":"Extra 89 lunch","dinner":"Extra 89 dinner","snacks":"Extra 89 snacks"}', 'Additional seed plan 89 for senior care');

INSERT INTO plans (title, diet_pref, fitness_goal, difficulty, workout_json, meal_json, notes) VALUES
('Any Senior Care Advanced Plan 90', 'Any', 'Senior Care', 'Advanced', '{"daily_workout":[{"name":"Special 90A","duration":25},{"name":"Special 90B","duration":15}],"weekly_schedule":{"Mon":["Routine"],"Tue":["Walk"],"Wed":["Routine"],"Thu":["Walk"],"Fri":["Routine"],"Sat":["Light"],"Sun":["Rest"]}}', '{"breakfast":"Extra 90 breakfast","lunch":"Extra 90 lunch","dinner":"Extra 90 dinner","snacks":"Extra 90 snacks"}', 'Additional seed plan 90 for senior care');
