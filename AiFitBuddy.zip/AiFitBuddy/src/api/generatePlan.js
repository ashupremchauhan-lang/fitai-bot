const path = require('path');
const Database = require('better-sqlite3');
const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', '..', 'db', 'aifitbuddy.db');
const db = new Database(DB_PATH);

function computeBMR(age, weight, height, gender) {
  // Mifflin-St Jeor
  if (!age || !weight || !height) return null;
  if (gender && gender.toLowerCase().startsWith('m')) {
    return Math.round(10 * weight + 6.25 * height - 5 * age + 5);
  }
  return Math.round(10 * weight + 6.25 * height - 5 * age - 161);
}

function computeTDEE(bmr, activity_level) {
  if (!bmr) return null;
  const map = {
    'Sedentary': 1.2,
    'Light': 1.375,
    'Moderate': 1.55,
    'High': 1.725
  };
  const mult = map[activity_level] || 1.375;
  return Math.round(bmr * mult);
}

module.exports = (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Missing email' });

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return res.status(404).json({ error: 'User not found' });

  // compute BMR/TDEE
  const bmr = computeBMR(user.age, user.weight, user.height, user.gender);
  const tdee = computeTDEE(bmr, user.activity_level);

  // try to find exact plan match
  let plan = db.prepare('SELECT * FROM plans WHERE diet_pref IN (?, "Any") AND fitness_goal = ? ORDER BY difficulty').get(user.diet_pref, user.fitness_goal);
  if (!plan) {
    // fallback: any plan matching fitness goal
    plan = db.prepare('SELECT * FROM plans WHERE fitness_goal = ? ORDER BY difficulty').get(user.fitness_goal);
  }
  if (!plan) {
    // fallback: any general plan
    plan = db.prepare('SELECT * FROM plans LIMIT 1').get();
  }

  // parse JSON fields
  try {
    plan.workout = plan.workout_json ? JSON.parse(plan.workout_json) : {};
    plan.meal = plan.meal_json ? JSON.parse(plan.meal_json) : {};
  } catch (err) {
    plan.workout = {};
    plan.meal = {};
  }

  const response = {
    user: {
      name: user.name,
      email: user.email,
      age: user.age,
      weight: user.weight,
      height: user.height,
      bmi: user.bmi
    },
    bmr,
    tdee,
    selected_plan: {
      id: plan.id,
      title: plan.title,
      notes: plan.notes,
      workout: plan.workout,
      meal: plan.meal
    }
  };

  res.json(response);
};