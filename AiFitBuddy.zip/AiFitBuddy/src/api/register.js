const path = require('path');
const Database = require('better-sqlite3');
const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', '..', 'db', 'aifitbuddy.db');
const db = new Database(DB_PATH);

function computeBMI(weight, heightCm) {
  if (!weight || !heightCm) return null;
  const h = heightCm / 100;
  return +(weight / (h * h)).toFixed(2);
}

module.exports = (req, res) => {
  const data = req.body;
  // basic validation
  const required = ['name', 'dob', 'email', 'age', 'weight', 'height', 'gender', 'activity_level', 'fitness_goal', 'diet_pref'];
  for (const f of required) {
    if (!data[f]) return res.status(400).json({ error: `Missing field: ${f}` });
  }

  const age = parseInt(data.age, 10);
  const weight = parseFloat(data.weight);
  const height = parseFloat(data.height);

  if (isNaN(age) || age < 10 || age > 120) return res.status(400).json({ error: 'Invalid age' });
  if (isNaN(weight) || weight < 20) return res.status(400).json({ error: 'Invalid weight' });
  if (isNaN(height) || height < 50) return res.status(400).json({ error: 'Invalid height' });

  const bmi = computeBMI(weight, height);

  // duplicate check: email OR combination name+dob+email
  const existing = db.prepare('SELECT * FROM users WHERE email = ?').get(data.email);
  if (existing) return res.status(409).json({ error: 'Duplicate entry: a profile with this email already exists.' });

  const stmt = db.prepare(`INSERT INTO users (name,dob,email,age,weight,height,gender,activity_level,weight_goal,fitness_goal,medical_history,allergies,diet_pref,bmi) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  try {
    const info = stmt.run(data.name, data.dob, data.email, age, weight, height, data.gender, data.activity_level, data.weight_goal || '', data.fitness_goal, data.medical_history || '', data.allergies || '', data.diet_pref, bmi);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
    res.status(201).json({ message: 'User registered', user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database insert failed' });
  }
};