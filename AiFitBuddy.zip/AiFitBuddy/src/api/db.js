const path = require('path');
const Database = require('better-sqlite3');
const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', '..', 'db', 'aifitbuddy.db');

const db = new Database(DB_PATH);

module.exports = {
  db,
  getUserByEmail: (req, res) => {
    const email = req.params.email;
    try {
      const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
      if (!row) return res.status(404).json({ error: 'User not found' });
      res.json(row);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Server error' });
    }
  },
  getPlans: (req, res) => {
    try {
      const rows = db.prepare('SELECT id,title,diet_pref,fitness_goal,difficulty,notes FROM plans').all();
      res.json(rows);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Server error' });
    }
  }
};